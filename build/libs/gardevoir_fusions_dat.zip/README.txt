Install this ZIP in your world datapacks folder or your server datapacks folder and reload.

This pack contains Cobblemon species additions/features and InfiniteFusion fusion definitions extracted from the InfiniteFusion test project.
It is intended for Minecraft 1.21.1.
