Install this ZIP in your Minecraft resourcepacks folder and enable it in-game.

This pack contains the Cobblemon fusion visual assets and language entries extracted from the InfiniteFusion test project.
It is intended for Minecraft 1.21.1.
